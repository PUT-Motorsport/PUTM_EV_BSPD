Version 4
SymbolType CELL
LINE Normal -32 -32 32 0
LINE Normal -32 32 32 0
LINE Normal -32 -32 -32 32
LINE Normal -28 -16 -20 -16
LINE Normal -28 16 -20 16
LINE Normal -24 20 -24 12
LINE Normal 0 -32 0 -16
LINE Normal 0 32 0 16
LINE Normal 4 -20 12 -20
LINE Normal 8 -24 8 -16
LINE Normal 4 20 12 20
SYMATTR Prefix X
SYMATTR SpiceModel lmc7215
SYMATTR ModelFile Sborka.lib
SYMATTR Description 2-8V, 0.7uA, 25uS
PIN -32 16 NONE 0
PINATTR PinName In+
PINATTR SpiceOrder 1
PIN -32 -16 NONE 0
PINATTR PinName In-
PINATTR SpiceOrder 2
PIN 32 0 NONE 0
PINATTR PinName OUT
PINATTR SpiceOrder 3
PIN 0 -32 NONE 0
PINATTR PinName V+
PINATTR SpiceOrder 4
PIN 0 32 NONE 0
PINATTR PinName V-
PINATTR SpiceOrder 5
