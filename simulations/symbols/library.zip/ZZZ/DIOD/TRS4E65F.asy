Version 4
SymbolType CELL
LINE Normal 0 36 4 36
LINE Normal 0 44 0 36
LINE Normal 0 44 32 44
LINE Normal 32 44 32 52
LINE Normal 32 52 28 52
LINE Normal 0 20 32 20
LINE Normal 32 20 16 44
LINE Normal 0 20 16 44
LINE Normal 16 0 16 20
LINE Normal 16 44 16 64
WINDOW 0 24 0 Left 2
WINDOW 3 24 64 Left 2
SYMATTR Value TRS4E65F
SYMATTR Prefix x
SYMATTR Description Schottky diode
SYMATTR ModelFile TRS4E65F.lib
PIN 16 0 NONE 0
PINATTR PinName +
PINATTR SpiceOrder 1
PIN 16 64 NONE 0
PINATTR PinName -
PINATTR SpiceOrder 2
