Version 4
SymbolType CELL
LINE Normal 17 0 -23 0
LINE Normal -23 0 -35 11
LINE Normal -23 0 -35 -10
LINE Normal 17 32 -23 32
LINE Normal -23 32 -35 43
LINE Normal -23 32 -35 22
LINE Normal 17 64 -23 64
LINE Normal -23 64 -35 75
LINE Normal -23 64 -35 54
LINE Normal 17 -32 -23 -32
LINE Normal -23 -32 -35 -21
LINE Normal -23 -32 -35 -42
LINE Normal 17 -64 -23 -64
LINE Normal -23 -64 -35 -53
LINE Normal -23 -64 -35 -74
LINE Normal -3 128 -4 -64
LINE Normal 8 -64 9 128
LINE Normal 17 96 -23 96
LINE Normal -23 96 -35 107
LINE Normal -23 96 -35 86
LINE Normal 17 128 -23 128
LINE Normal -23 128 -35 139
LINE Normal -23 128 -35 118
TEXT -16 -74 Left 2 1
TEXT -17 -42 Left 2 2
TEXT -17 -11 Left 2 3
TEXT -17 23 Left 2 4
TEXT -17 54 Left 2 5
TEXT -17 86 Left 2 6
TEXT -17 118 Left 2 7
SYMATTR SpiceModel rozetka7
SYMATTR ModelFile Sborka.lib
PIN 16 -64 NONE 8
PINATTR PinName 1
PINATTR SpiceOrder 1
PIN 16 -32 NONE 8
PINATTR PinName 2
PINATTR SpiceOrder 2
PIN 16 0 NONE 8
PINATTR PinName 3
PINATTR SpiceOrder 3
PIN 16 32 NONE 8
PINATTR PinName 4
PINATTR SpiceOrder 4
PIN 16 64 NONE 8
PINATTR PinName 5
PINATTR SpiceOrder 5
PIN 16 96 NONE 8
PINATTR PinName 6
PINATTR SpiceOrder 6
PIN 16 128 NONE 8
PINATTR PinName 7
PINATTR SpiceOrder 7
